import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { createScheme } from "../../../api/schemesApi";

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  amount: z.preprocess((val) => Number(val), z.number().min(0, "Amount must be non-negative")),
  eligibility_criteria: z.string().min(1, "Eligibility is required"),
  application_deadline: z.preprocess((val) => new Date(val), z.date()),
  exam_date: z.preprocess((val) => new Date(val), z.date()),
  duration: z.union([z.string(), z.number()]),
  mode: z.enum(["Online", "Offline", "Hybrid"]),
});

const AddSchemeModal = () => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data) => {
    try {
      await createScheme(data);
      reset();
      document.getElementById("add_scheme_modal").close();
      window.location.reload();
    } catch (err) {
      console.error("Error creating scheme:", err);
    }
  };

  return (
    <dialog id="add_scheme_modal" className="modal">
      <div className="modal-box">
        <h3 className="text-lg font-semibold mb-4">Add New Scheme</h3>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block mb-1">Title</label>
            <input {...register("title")} className="input input-bordered w-full" />
            {errors.title && <p className="text-red-500">{errors.title.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Description</label>
            <textarea {...register("description")} className="textarea textarea-bordered w-full" />
            {errors.description && <p className="text-red-500">{errors.description.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Amount</label>
            <input type="number" {...register("amount")} className="input input-bordered w-full" />
            {errors.amount && <p className="text-red-500">{errors.amount.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Eligibility Criteria</label>
            <input {...register("eligibility_criteria")} className="input input-bordered w-full" />
            {errors.eligibility_criteria && <p className="text-red-500">{errors.eligibility_criteria.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Application Deadline</label>
            <input type="date" {...register("application_deadline")} className="input input-bordered w-full" />
            {errors.application_deadline && <p className="text-red-500">{errors.application_deadline.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Exam Date</label>
            <input type="date" {...register("exam_date")} className="input input-bordered w-full" />
            {errors.exam_date && <p className="text-red-500">{errors.exam_date.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Duration</label>
            <input {...register("duration")} className="input input-bordered w-full" />
            {errors.duration && <p className="text-red-500">{errors.duration.message}</p>}
          </div>

          <div>
            <label className="block mb-1">Mode</label>
            <select {...register("mode")} className="select select-bordered w-full">
              <option value="">Select Mode</option>
              <option value="Online">Online</option>
              <option value="Offline">Offline</option>
              <option value="Hybrid">Hybrid</option>
            </select>
            {errors.mode && <p className="text-red-500">{errors.mode.message}</p>}
          </div>

          <button type="submit" className="bg-emerald-600 text-white px-4 py-2 rounded-lg">
            Save
          </button>
        </form>
      </div>
    </dialog>
  );
};

export default AddSchemeModal;
