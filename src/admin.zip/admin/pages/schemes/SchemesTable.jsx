import { useState, useEffect } from 'react';
import { PencilIcon, TrashIcon } from '@heroicons/react/24/outline';
import useSchemes from '../../../hooks/useSchemes';
import AddSchemeModal from './AddSchemeModal';
import EditSchemeForm from './EditSchemeForm';

const SchemesTable = () => {
  const { schemes, loading, error, deleteScheme } = useSchemes();
  const [editingScheme, setEditingScheme] = useState(null);

  if (loading) return <p>Loading...</p>;
  if (error) return <p className="text-red-500">{error.message}</p>;
console.log("schemes:", schemes, "type:", typeof schemes);

  return (
    <>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th>Title</th>
              <th>Amount</th>
              <th>Deadline</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {schemes.map((scheme) => (
              <tr key={scheme._id} className="hover:bg-gray-50">
                <td className="px-6 py-4">{scheme.title}</td>
                <td className="px-6 py-4">₹{scheme.amount}</td>
                <td className="px-6 py-4">{new Date(scheme.application_deadline).toLocaleDateString()}</td>
                <td className="px-6 py-4 flex space-x-2">
                  <button 
                    onClick={() => setEditingScheme(scheme)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <PencilIcon className="h-5 w-5" />
                  </button>
                  <button 
                    onClick={() => deleteScheme(scheme._id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <TrashIcon className="h-5 w-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AddSchemeModal />
      {editingScheme && (
        <EditSchemeForm scheme={editingScheme} onClose={() => setEditingScheme(null)} />
      )}
    </>
  );
};

export default SchemesTable;