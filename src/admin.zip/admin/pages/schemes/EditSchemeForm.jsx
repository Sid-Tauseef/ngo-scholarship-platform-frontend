import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { useEffect } from "react";
import { updateScheme } from "../../../api/schemesApi"; // <-- named import

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  amount: z
    .number({ invalid_type_error: "Amount must be a number" })
    .min(0, "Amount must be non-negative"),
  eligibility_criteria: z.string().min(1, "Eligibility criteria is required"),
  application_deadline: z.date(),
  exam_date: z.date(),
  duration: z.union([z.string(), z.number()]),
  mode: z.enum(["Online", "Offline", "Hybrid"]),
});

const EditSchemeForm = ({ scheme, onClose }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      title: scheme.title,
      description: scheme.description,
      amount: scheme.amount,
      eligibility_criteria: scheme.eligibility_criteria,
      application_deadline: new Date(scheme.application_deadline),
      exam_date: new Date(scheme.exam_date),
      duration: scheme.duration,
      mode: scheme.mode,
    },
  });

  useEffect(() => {
    reset({
      title: scheme.title,
      description: scheme.description,
      amount: scheme.amount,
      eligibility_criteria: scheme.eligibility_criteria,
      application_deadline: new Date(scheme.application_deadline),
      exam_date: new Date(scheme.exam_date),
      duration: scheme.duration,
      mode: scheme.mode,
    });
  }, [scheme, reset]);

  const onSubmit = async (data) => {
    try {
      await updateScheme(scheme._id, data);
      window.location.reload(); // You can replace this with better UX (like a toast)
    } catch (err) {
      console.error("Error updating scheme:", err);
    }
  };

  return (
    <dialog id="edit_scheme_modal" className="modal" open>
      <div className="modal-box relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <XMarkIcon className="h-5 w-5" />
        </button>
        <h3 className="text-lg font-semibold mb-4">Edit Scheme</h3>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label>Title</label>
            <input
              type="text"
              {...register("title")}
              className="input input-bordered w-full"
            />
            {errors.title && (
              <p className="text-red-500">{errors.title.message}</p>
            )}
          </div>

          <div>
            <label>Description</label>
            <textarea
              {...register("description")}
              className="textarea textarea-bordered w-full"
            />
            {errors.description && (
              <p className="text-red-500">{errors.description.message}</p>
            )}
          </div>

          <div>
            <label>Amount</label>
            <input
              type="number"
              {...register("amount", { valueAsNumber: true })}
              className="input input-bordered w-full"
            />
            {errors.amount && (
              <p className="text-red-500">{errors.amount.message}</p>
            )}
          </div>

          <div>
            <label>Eligibility Criteria</label>
            <input
              type="text"
              {...register("eligibility_criteria")}
              className="input input-bordered w-full"
            />
            {errors.eligibility_criteria && (
              <p className="text-red-500">
                {errors.eligibility_criteria.message}
              </p>
            )}
          </div>

          <div>
            <label>Application Deadline</label>
            <input
              type="date"
              {...register("application_deadline", { valueAsDate: true })}
              className="input input-bordered w-full"
            />
            {errors.application_deadline && (
              <p className="text-red-500">
                {errors.application_deadline.message}
              </p>
            )}
          </div>

          <div>
            <label>Exam Date</label>
            <input
              type="date"
              {...register("exam_date", { valueAsDate: true })}
              className="input input-bordered w-full"
            />
            {errors.exam_date && (
              <p className="text-red-500">{errors.exam_date.message}</p>
            )}
          </div>

          <div>
            <label>Duration</label>
            <input
              type="text"
              {...register("duration")}
              className="input input-bordered w-full"
            />
            {errors.duration && (
              <p className="text-red-500">{errors.duration.message}</p>
            )}
          </div>

          <div>
            <label>Mode</label>
            <select
              {...register("mode")}
              className="select select-bordered w-full"
            >
              <option value="">Select Mode</option>
              <option value="Online">Online</option>
              <option value="Offline">Offline</option>
              <option value="Hybrid">Hybrid</option>
            </select>
            {errors.mode && (
              <p className="text-red-500">{errors.mode.message}</p>
            )}
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-emerald-600 text-white px-4 py-2 rounded-lg"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </dialog>
  );
};

export default EditSchemeForm;
