import { useState } from 'react';
import { Bars3Icon } from '@heroicons/react/24/outline';
import Navbar from '../../components/Navbar';
import AdminSidebar from '../components/DashboardLayout/AdminSidebar';
import SchemesTable from './schemes/SchemesTable';

const ManageSchemes = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="fixed top-0 left-0 right-0 z-50">
        <Navbar />
      </header>
      <AdminSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main className="max-w-7xl mx-auto p-6 pt-20 lg:pl-72">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Manage Scholarship Schemes</h1>
          <button
            onClick={() => document.getElementById('add_scheme_modal').showModal()}
            className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700"
          >
            Add New Scheme
          </button>
        </div>
        <SchemesTable />
      </main>
    </div>
  );
};

export default ManageSchemes;