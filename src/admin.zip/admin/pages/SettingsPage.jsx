// front/ngo-scholarship-platform-frontend/src/admin/pages/SettingsPage.jsx
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const schema = z.object({
  platformName: z.string().min(1, 'Platform name is required'),
  contactEmail: z.string().email('Invalid email format'),
});

const SettingsPage = () => {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      platformName: 'Maulana Zahid Educational Trust', // Example default value
      contactEmail: 'contact@example.com', // Example default value
    },
  });

  const onSubmit = (data) => {
    console.log('Settings updated:', data);
    // TODO: Implement API call to update settings (e.g., via a settingsApi)
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Settings</h2>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Platform Name</label>
          <input
            {...register('platformName')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
          />
          {errors.platformName && <p className="text-red-500 text-sm mt-1">{errors.platformName.message}</p>}
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Contact Email</label>
          <input
            type="email"
            {...register('contactEmail')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
          />
          {errors.contactEmail && <p className="text-red-500 text-sm mt-1">{errors.contactEmail.message}</p>}
        </div>
        
        <button
          type="submit"
          className="w-full bg-emerald-600 text-white py-2 px-4 rounded-md hover:bg-emerald-700"
        >
          Save Settings
        </button>
      </form>
    </div>
  );
};

export default SettingsPage;