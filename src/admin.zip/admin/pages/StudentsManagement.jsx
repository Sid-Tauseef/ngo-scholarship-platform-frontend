// front/ngo-scholarship-platform-frontend/src/admin/pages/StudentsManagement.jsx
import StudentsTable from '../components/students/StudentsTable';

const StudentsManagement = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Students Management</h2>
      <StudentsTable />
    </div>
  );
};

export default StudentsManagement;