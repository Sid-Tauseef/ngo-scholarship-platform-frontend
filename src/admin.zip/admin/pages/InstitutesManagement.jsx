// front/ngo-scholarship-platform-frontend/src/admin/pages/InstitutesManagement.jsx
import InstitutesTable from '../components/institutes/InstitutesTable';

const InstitutesManagement = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Institutes Management</h2>
      <InstitutesTable />
    </div>
  );
};

export default InstitutesManagement;