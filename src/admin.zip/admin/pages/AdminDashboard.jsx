import { Outlet } from 'react-router-dom';
import AdminSidebar from '../components/DashboardLayout/AdminSidebar';
import { useState } from 'react';
import { Bars3Icon } from '@heroicons/react/24/outline';
import Navbar from '../../components/Navbar';

const AdminDashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Fixed Navbar */}
      <header className="fixed top-0 left-0 right-0 z-50">
        <Navbar />
      </header>

      {/* Mobile Sidebar Toggle */}
      <button
        onClick={() => setSidebarOpen(true)}
        className="lg:hidden fixed top-16 right-4 p-2 z-50 bg-white rounded-lg shadow-sm border border-gray-200"
      >
        <Bars3Icon className="h-6 w-6 text-gray-600" />
      </button>

      <AdminSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Main content */}
      <div className="lg:ml-64 pt-16">
        <main className="p-6">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;