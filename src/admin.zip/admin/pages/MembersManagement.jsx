import MembersTable from '../components/members/MembersTable';

const MembersManagement = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Members Management</h2>
      <MembersTable />
    </div>
  );
};

export default MembersManagement;