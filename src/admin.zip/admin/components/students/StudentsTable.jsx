// front/ngo-scholarship-platform-frontend/src/admin/components/students/StudentsTable.jsx
import { useState } from "react";
import { PencilIcon, TrashIcon, UserPlusIcon, EllipsisVerticalIcon } from "@heroicons/react/24/outline";
import useStudents from "../../../hooks/useStudents";
import AddStudentModal from "./AddStudentModal";
import EditStudentForm from "./EditStudentForm";

const StudentsTable = () => {
  const { students, loading, error, addStudent, updateStudent, deleteStudent } = useStudents();
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [actionMenuOpen, setActionMenuOpen] = useState(null);

  const handleAddStudent = async (data) => {
    try {
      await addStudent(data);
      setAddModalOpen(false);
    } catch (error) {
      console.error("Error adding student:", error);
    }
  };

  const handleUpdateStudent = async (data) => {
    if (selectedStudent) {
      try {
        await updateStudent(selectedStudent.id, data);
        setSelectedStudent(null);
      } catch (error) {
        console.error("Error updating student:", error);
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Students</h3>
          <p className="text-sm text-gray-500 mt-1">Manage students</p>
        </div>
        <button
          onClick={() => setAddModalOpen(true)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center hover:bg-emerald-700 transition-colors"
        >
          <UserPlusIcon className="h-5 w-5 mr-2" />
          Add Student
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {students.map((student) => (
              <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">{student.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{student.email}</td>
                <td className="px-6 py-4 whitespace-nowrap relative">
                  <button
                    onClick={() => setActionMenuOpen(actionMenuOpen === student.id ? null : student.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <EllipsisVerticalIcon className="h-5 w-5" />
                  </button>
                  
                  {actionMenuOpen === student.id && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10">
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setSelectedStudent(student);
                            setActionMenuOpen(null);
                          }}
                          className="w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                        >
                          <PencilIcon className="h-4 w-4 mr-2" />
                          Edit
                        </button>
                        <button
                          onClick={() => deleteStudent(student.id)}
                          className="w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                        >
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Delete
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AddStudentModal
        isOpen={isAddModalOpen}
        onClose={() => setAddModalOpen(false)}
        onSubmit={handleAddStudent}
      />

      {selectedStudent && (
        <EditStudentForm
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          onSubmit={handleUpdateStudent}
        />
      )}

      {loading && (
        <div className="p-4 text-center text-gray-500">
          Loading...
        </div>
      )}
      {error && (
        <div className="p-4 text-center text-red-500">
          Error: {error}
        </div>
      )}
    </div>
  );
};

export default StudentsTable;