// AdminSidebar.jsx
import { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  ChartBarIcon,
  UsersIcon,
  AcademicCapIcon,
  BuildingLibraryIcon,
  CogIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  XMarkIcon,
  MegaphoneIcon
} from "@heroicons/react/24/outline";

const navigation = [
  { name: "Dashboard", href: "/admin/dashboard", icon: ChartBarIcon },
  { name: "Members", href: "/admin/dashboard/members", icon: UsersIcon },
  { name: "Students", href: "/admin/dashboard/students", icon: AcademicCapIcon },
  { name: "Institutes", href: "/admin/dashboard/institutes", icon: BuildingLibraryIcon },
  { name: "Schemes", href: "/admin/dashboard/schemes", icon: MegaphoneIcon }, // New item
  { name: "Settings", href: "/admin/dashboard/settings", icon: CogIcon },
];

const AdminSidebar = ({ isOpen, onClose }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    // Update the main container class to account for navbar
    <div
      className={`fixed inset-y-0 left-0 bg-white shadow-lg
  transform ${isOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0
  transition-transform duration-200 ease-in-out
  z-40  // Reduced z-index to be below navbar
  ${isCollapsed ? "w-20" : "w-64"}
  mt-16 // Add margin-top to account for navbar height
`}
    >
      {/* HEADER */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        {/* Logo / Title */}
        {!isCollapsed && (
          <h2 className="text-xl font-bold text-emerald-600">
            Admin Dashboard
          </h2>
        )}

        <div className="flex items-center space-x-2">
          {/* Collapse / Expand toggle */}
          <button
            onClick={() => setIsCollapsed((v) => !v)}
            className="p-1 rounded hover:bg-gray-100"
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? (
              <ChevronRightIcon className="h-6 w-6 text-gray-600" />
            ) : (
              <ChevronLeftIcon className="h-6 w-6 text-gray-600" />
            )}
          </button>

          {/* Mobile close button */}
          <button
            onClick={onClose}
            className="lg:hidden p-1 rounded hover:bg-gray-100"
            aria-label="Close sidebar"
          >
            <XMarkIcon className="h-6 w-6 text-gray-600" />
          </button>
        </div>
      </div>

      {/* NAVIGATION */}
      <nav className="mt-4">
        {navigation.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            className={({ isActive }) => `
              flex items-center
              px-4 py-3 mx-2 my-1
              rounded-lg transition-colors
              ${
                isActive
                  ? "bg-emerald-50 text-emerald-700 font-semibold"
                  : "text-gray-600 hover:bg-gray-100"
              }
              ${isCollapsed ? "justify-center" : ""}
            `}
          >
            <item.icon
              className={`h-5 w-5
                ${isCollapsed ? "" : "mr-3"}
              `}
            />
            {/* hide label when collapsed */}
            {!isCollapsed && <span>{item.name}</span>}
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default AdminSidebar;
