// AdminHeader.jsx
import { useAppDispatch } from '../../../hooks/useAppDispatch';
import { logout } from '../../../features/auth/authSlice';
import { UserCircleIcon, ChevronDownIcon } from '@heroicons/react/24/outline';
import { useNavigate } from 'react-router-dom';

const AdminHeader = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white h-16 shadow-sm border-b border-gray-200">
      <div className="h-full flex items-center justify-between px-6">
        <h1 className="text-xl font-semibold text-gray-800">Admin Dashboard</h1>
        <div className="flex items-center space-x-4">
          <div className="relative group">
            <button className="flex items-center space-x-2">
              <UserCircleIcon className="h-8 w-8 text-gray-600" />
              <ChevronDownIcon className="h-4 w-4 text-gray-600" />
            </button>
            <div className="hidden group-hover:block absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1">
              <button
                onClick={() => {
                  dispatch(logout());
                  navigate('/login');
                }}
                className="block w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
