import { useState } from "react";
import { PencilIcon, TrashIcon, UserPlusIcon, EllipsisVerticalIcon } from "@heroicons/react/24/outline";
import useMembers from "../../../hooks/useMembers";
import AddMemberModal from "./AddMemberModal";
import EditMemberForm from "./EditMemberForm";

const MembersTable = () => {
  const { members, loading, error, addMember, updateMember, deleteMember } = useMembers();
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);
  const [actionMenuOpen, setActionMenuOpen] = useState(null);

  const handleAddMember = async (data) => {
    try {
      await addMember(data);
      setAddModalOpen(false);
    } catch (error) {
      console.error("Error adding member:", error);
    }
  };

  const handleUpdateMember = async (data) => {
    if (selectedMember) {
      try {
        await updateMember(selectedMember.id, data);
        setSelectedMember(null);
      } catch (error) {
        console.error("Error updating member:", error);
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Team Members</h3>
          <p className="text-sm text-gray-500 mt-1">Manage your organization's members</p>
        </div>
        <button
          onClick={() => setAddModalOpen(true)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center hover:bg-emerald-700 transition-colors"
        >
          <UserPlusIcon className="h-5 w-5 mr-2" />
          Add Member
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {members.map((member) => (
              <tr key={member.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">{member.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{member.email}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 text-sm rounded-full bg-emerald-100 text-emerald-700">
                    {member.role}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap relative">
                  <button
                    onClick={() => setActionMenuOpen(actionMenuOpen === member.id ? null : member.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <EllipsisVerticalIcon className="h-5 w-5" />
                  </button>
                  
                  {actionMenuOpen === member.id && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10">
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setSelectedMember(member);
                            setActionMenuOpen(null);
                          }}
                          className="w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                        >
                          <PencilIcon className="h-4 w-4 mr-2" />
                          Edit
                        </button>
                        <button
                          onClick={() => deleteMember(member.id)}
                          className="w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                        >
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Delete
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Member Modal */}
      <AddMemberModal
        isOpen={isAddModalOpen}
        onClose={() => setAddModalOpen(false)}
        onSubmit={handleAddMember}
      />

      {/* Edit Member Modal */}
      {selectedMember && (
        <EditMemberForm
          member={selectedMember}
          onClose={() => setSelectedMember(null)}
          onSubmit={handleUpdateMember}
        />
      )}

      {/* Loading and Error States */}
      {loading && (
        <div className="p-4 text-center text-gray-500">
          Loading...
        </div>
      )}
      {error && (
        <div className="p-4 text-center text-red-500">
          Error: {error.message}
        </div>
      )}
    </div>
  );
};

export default MembersTable;