// front/ngo-scholarship-platform-frontend/src/admin/components/institutes/InstitutesTable.jsx
import { useState } from "react";
import { PencilIcon, TrashIcon, UserPlusIcon, EllipsisVerticalIcon } from "@heroicons/react/24/outline";
import useInstitutes from "../../../hooks/useInstitutes";
import AddInstituteModal from "./AddInstituteModal";
import EditInstituteForm from "./EditInstituteForm";

const InstitutesTable = () => {
  const { institutes, loading, error, addInstitute, updateInstitute, deleteInstitute } = useInstitutes();
  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [selectedInstitute, setSelectedInstitute] = useState(null);
  const [actionMenuOpen, setActionMenuOpen] = useState(null);

  const handleAddInstitute = async (data) => {
    try {
      await addInstitute(data);
      setAddModalOpen(false);
    } catch (error) {
      console.error("Error adding institute:", error);
    }
  };

  const handleUpdateInstitute = async (data) => {
    if (selectedInstitute) {
      try {
        await updateInstitute(selectedInstitute.id, data);
        setSelectedInstitute(null);
      } catch (error) {
        console.error("Error updating institute:", error);
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Institutes</h3>
          <p className="text-sm text-gray-500 mt-1">Manage institutes</p>
        </div>
        <button
          onClick={() => setAddModalOpen(true)}
          className="bg-emerald-600 text-white px-4 py-2 rounded-lg flex items-center hover:bg-emerald-700 transition-colors"
        >
          <UserPlusIcon className="h-5 w-5 mr-2" />
          Add Institute
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {institutes.map((institute) => (
              <tr key={institute.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">{institute.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{institute.email}</td>
                <td className="px-6 py-4 whitespace-nowrap relative">
                  <button
                    onClick={() => setActionMenuOpen(actionMenuOpen === institute.id ? null : institute.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <EllipsisVerticalIcon className="h-5 w-5" />
                  </button>
                  
                  {actionMenuOpen === institute.id && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10">
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setSelectedInstitute(institute);
                            setActionMenuOpen(null);
                          }}
                          className="w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                        >
                          <PencilIcon className="h-4 w-4 mr-2" />
                          Edit
                        </button>
                        <button
                          onClick={() => deleteInstitute(institute.id)}
                          className="w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                        >
                          <TrashIcon className="h-4 w-4 mr-2" />
                          Delete
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AddInstituteModal
        isOpen={isAddModalOpen}
        onClose={() => setAddModalOpen(false)}
        onSubmit={handleAddInstitute}
      />

      {selectedInstitute && (
        <EditInstituteForm
          institute={selectedInstitute}
          onClose={() => setSelectedInstitute(null)}
          onSubmit={handleUpdateInstitute}
        />
      )}

      {loading && (
        <div className="p-4 text-center text-gray-500">
          Loading...
        </div>
      )}
      {error && (
        <div className="p-4 text-center text-red-500">
          Error: {error}
        </div>
      )}
    </div>
  );
};

export default InstitutesTable;